<?php
session_start();
session_destroy();
echo 'You have been logged out. <a href="http://multibot.tech/">Go back</a>';